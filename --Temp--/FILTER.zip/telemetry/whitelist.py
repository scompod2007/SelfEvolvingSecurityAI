"""
Whitelist definitions and helper functions for the telemetry filtering framework.
"""

from typing import Set

TRUSTED_PROCESSES: Set[str] = set()
TRUSTED_FILES: Set[str] = set()
TRUSTED_PATHS: Set[str] = set()
TRUSTED_IPS: Set[str] = set()
TRUSTED_REGISTRY: Set[str] = set()
TRUSTED_SERVICES: Set[str] = set()


def is_trusted_process(process_name: str) -> bool:
    """Check if a process is in the trusted whitelist."""
    if not process_name:
        return False
    return process_name.lower() in TRUSTED_PROCESSES


def is_trusted_file(file_name: str) -> bool:
    """Check if a file is in the trusted whitelist."""
    if not file_name:
        return False
    return file_name.lower() in TRUSTED_FILES


def is_trusted_path(path: str) -> bool:
    """Check if a path is in the trusted whitelist."""
    if not path:
        return False
    path_lower = path.lower()
    return any(trusted in path_lower for trusted in TRUSTED_PATHS)


def is_trusted_ip(ip_address: str) -> bool:
    """Check if an IP address is in the trusted whitelist."""
    if not ip_address:
        return False
    return ip_address in TRUSTED_IPS


def is_trusted_registry(registry_key: str) -> bool:
    """Check if a registry key is in the trusted whitelist."""
    if not registry_key:
        return False
    key_lower = registry_key.lower()
    return any(trusted in key_lower for trusted in TRUSTED_REGISTRY)


def is_trusted_service(service_name: str) -> bool:
    """Check if a service is in the trusted whitelist."""
    if not service_name:
        return False
    return service_name.lower() in TRUSTED_SERVICES
