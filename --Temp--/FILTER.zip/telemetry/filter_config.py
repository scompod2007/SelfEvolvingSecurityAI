"""
Configuration for the telemetry filtering framework.
All switches and values are configurable here without magic numbers in the logic.
"""

from typing import Set

# Feature Toggles
ENABLE_FILE_FILTER: bool = True
ENABLE_PROCESS_FILTER: bool = True
ENABLE_NETWORK_FILTER: bool = True
ENABLE_REGISTRY_FILTER: bool = True
ENABLE_DUPLICATE_FILTER: bool = True
ENABLE_PATTERN_FILTER: bool = True
ENABLE_EXTENSION_FILTER: bool = True
ENABLE_STATE_FILTER: bool = True
ENABLE_PORT_FILTER: bool = True
ENABLE_LOOPBACK_FILTER: bool = True
ENABLE_WHITELIST: bool = True

# Limits and Thresholds
MAX_EVENT_FREQUENCY: int = 1000
DUPLICATE_CACHE_SECONDS: float = 5.0
MAX_IGNORE_FILE_SIZE: int = 10 * 1024 * 1024  # 10 MB

# ----------------------------------------------------
# Filtering Lists
# ----------------------------------------------------

IGNORE_PATHS: Set[str] = {
    "appdata\\local\\temp",
    "windows\\prefetch",
    "$recycle.bin",
    "recycler",
}

IGNORE_FILES: Set[str] = {
    "telemetry.db",
    "telemetry.db-journal",
    "telemetry.db-wal",
    "telemetry.db-shm",
    "thumbs.db",
    "desktop.ini",
}

IGNORE_EXTENSIONS: Set[str] = {
    ".tmp",
    ".temp",
    ".log",
    ".etl",
}

IGNORE_PATTERNS: Set[str] = {
    "*.tmp",
    "*.etl",
    "*.cache",
    "*.bak",
    "*.old",
}

IGNORE_PROCESSES: Set[str] = {
    "system idle process",
}

IGNORE_USERS: Set[str] = {
    "system",
    "local service",
    "network service",
}

IGNORE_IPS: Set[str] = {
    "127.0.0.1",
    "::1",
}

IGNORE_PORTS: Set[int] = set()

IGNORE_STATES: Set[str] = {
    "time_wait",
}

IGNORE_REGISTRY: Set[str] = {
    "volatile environment",
    "muicache",
    "recentdocs",
}

IGNORE_SERVICES: Set[str] = set()

IGNORE_PROTOCOLS: Set[str] = set()

# ----------------------------------------------------
# AI Safety Rules - NEVER IGNORE
# ----------------------------------------------------

CRITICAL_EXTENSIONS: Set[str] = {
    ".exe",
    ".dll",
    ".ps1",
    ".bat",
    ".cmd",
    ".scr",
    ".vbs",
    ".js",
}

CRITICAL_REGISTRY_PATHS: Set[str] = {
    "run",
    "runonce",
    "services",
    "winlogon",
    "lsa",
    "windows defender",
    "policies",
}

CRITICAL_NETWORK_PROTOCOLS: Set[str] = {
    "http",
    "https",
    "dns",
    "ssh",
    "smb",
    "rdp",
}
