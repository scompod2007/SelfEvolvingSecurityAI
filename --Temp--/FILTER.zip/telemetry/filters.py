"""
Production-quality filtering engine for telemetry data.
Designed for the Self-Evolving Security AI to reduce noise without hiding suspicious activity.
"""

import fnmatch
import os
import time
from typing import Dict, Any, Tuple
from collections import defaultdict

import telemetry.filter_config as config
import telemetry.whitelist as whitelist


class TelemetryFilter:
    """
    Modular filtering framework for telemetry events.
    """

    def __init__(self) -> None:
        # Cache for duplicate detection: (event_type, identifier, action) -> timestamp
        self._duplicate_cache: Dict[Tuple[str, str, str], float] = {}
        
        # Frequency limiter: (event_type, identifier) -> count
        self._frequency_counter: Dict[Tuple[str, str], int] = defaultdict(int)
        
        # Statistics for maintaining ignored counters and seen metrics
        self.stats: Dict[str, int] = {
            "files_seen": 0,
            "files_filtered": 0,
            "files_saved": 0,
            "processes_seen": 0,
            "processes_filtered": 0,
            "processes_saved": 0,
            "registry_seen": 0,
            "registry_filtered": 0,
            "registry_saved": 0,
            "network_seen": 0,
            "network_filtered": 0,
            "network_saved": 0,
            "total_duplicates_filtered": 0,
            "total_frequency_filtered": 0,
        }

    def _clean_cache(self, current_time: float) -> None:
        """Remove expired entries from the duplicate cache."""
        expired_keys = [
            k for k, ts in self._duplicate_cache.items()
            if current_time - ts > config.DUPLICATE_CACHE_SECONDS
        ]
        for k in expired_keys:
            del self._duplicate_cache[k]

    def _is_duplicate(self, event_type: str, identifier: str, action: str, timestamp: float) -> bool:
        """Check if an event is a duplicate within the configured time window."""
        if not config.ENABLE_DUPLICATE_FILTER:
            return False

        self._clean_cache(timestamp)
        cache_key = (event_type, identifier, action)
        
        if cache_key in self._duplicate_cache:
            self.stats["total_duplicates_filtered"] += 1
            return True
            
        self._duplicate_cache[cache_key] = timestamp
        return False

    def _exceeds_frequency(self, event_type: str, identifier: str) -> bool:
        """Check if an event exceeds the maximum allowed frequency."""
        freq_key = (event_type, identifier)
        self._frequency_counter[freq_key] += 1
        
        if self._frequency_counter[freq_key] > config.MAX_EVENT_FREQUENCY:
            self.stats["total_frequency_filtered"] += 1
            return True
            
        return False

    def should_ignore_file(self, file_path: str, action: str, timestamp: float) -> bool:
        """
        Determine if a file event should be ignored based on paths, files, extensions, patterns, and safety rules.
        """
        self.stats["files_seen"] += 1
        
        if not file_path:
            return True

        path_lower = file_path.lower()
        file_name = os.path.basename(path_lower)
        _, ext = os.path.splitext(file_name)

        if config.ENABLE_WHITELIST and whitelist.is_trusted_file(file_name):
            self.stats["files_saved"] += 1
            return False

        if config.ENABLE_WHITELIST and whitelist.is_trusted_path(file_path):
            self.stats["files_saved"] += 1
            return False

        # AI Safety Rules - Never ignore critical extensions
        if ext in config.CRITICAL_EXTENSIONS:
            self.stats["files_saved"] += 1
            return False

        if not config.ENABLE_FILE_FILTER:
            self.stats["files_saved"] += 1
            return False

        if self._is_duplicate("file", path_lower, action, timestamp):
            self.stats["files_filtered"] += 1
            return True

        if self._exceeds_frequency("file", path_lower):
            self.stats["files_filtered"] += 1
            return True

        # Ignore specific database files
        if file_name in config.IGNORE_FILES:
            self.stats["files_filtered"] += 1
            return True

        # Ignore by extension
        if config.ENABLE_EXTENSION_FILTER and ext in config.IGNORE_EXTENSIONS:
            self.stats["files_filtered"] += 1
            return True

        # Ignore by pattern
        if config.ENABLE_PATTERN_FILTER:
            for pattern in config.IGNORE_PATTERNS:
                if fnmatch.fnmatch(file_name, pattern):
                    self.stats["files_filtered"] += 1
                    return True

        # Ignore by path
        for ignore_path in config.IGNORE_PATHS:
            if ignore_path in path_lower:
                self.stats["files_filtered"] += 1
                return True

        self.stats["files_saved"] += 1
        return False

    def should_ignore_process(self, process_name: str, process_path: str, username: str, action: str, timestamp: float) -> bool:
        """
        Determine if a process event should be ignored.
        """
        self.stats["processes_seen"] += 1

        if not process_name and not process_path:
            return True

        process_name_lower = process_name.lower() if process_name else ""
        process_path_lower = process_path.lower() if process_path else ""
        username_lower = username.lower() if username else ""

        if config.ENABLE_WHITELIST and whitelist.is_trusted_process(process_name_lower):
            self.stats["processes_saved"] += 1
            return False

        # AI Safety Rules - Never ignore critical extensions
        _, ext = os.path.splitext(process_path_lower)
        if ext in config.CRITICAL_EXTENSIONS:
            self.stats["processes_saved"] += 1
            return False

        if not config.ENABLE_PROCESS_FILTER:
            self.stats["processes_saved"] += 1
            return False

        identifier = process_path_lower if process_path_lower else process_name_lower
        if self._is_duplicate("process", identifier, action, timestamp):
            self.stats["processes_filtered"] += 1
            return True

        if self._exceeds_frequency("process", identifier):
            self.stats["processes_filtered"] += 1
            return True

        if process_name_lower in config.IGNORE_PROCESSES:
            self.stats["processes_filtered"] += 1
            return True

        if username_lower in config.IGNORE_USERS:
            self.stats["processes_filtered"] += 1
            return True

        self.stats["processes_saved"] += 1
        return False

    def should_ignore_network(
        self,
        src_ip: str,
        dst_ip: str,
        port: int,
        protocol: str,
        state: str,
        process_name: str,
        timestamp: float,
        is_listening_port: bool = False,
        is_new_outbound: bool = False
    ) -> bool:
        """
        Determine if a network event should be ignored.
        Includes AI safety checks for external IPs, unknown processes, and specific protocols.
        """
        self.stats["network_seen"] += 1
        
        protocol_lower = protocol.lower() if protocol else ""
        state_lower = state.lower() if state else ""

        if config.ENABLE_WHITELIST and whitelist.is_trusted_ip(dst_ip):
            self.stats["network_saved"] += 1
            return False

        # AI Safety Rules - Never ignore
        if is_listening_port or is_new_outbound:
            self.stats["network_saved"] += 1
            return False

        if protocol_lower in config.CRITICAL_NETWORK_PROTOCOLS:
            self.stats["network_saved"] += 1
            return False
            
        if not process_name: # Unknown process
            self.stats["network_saved"] += 1
            return False

        is_external = dst_ip and not (
            dst_ip.startswith("192.168.") or 
            dst_ip.startswith("10.") or 
            (dst_ip.startswith("172.") and 16 <= int(dst_ip.split(".")[1]) <= 31) or 
            dst_ip in {"127.0.0.1", "::1"}
        )
        if is_external and dst_ip not in config.IGNORE_IPS:
            self.stats["network_saved"] += 1
            return False

        if not config.ENABLE_NETWORK_FILTER:
            self.stats["network_saved"] += 1
            return False

        connection_id = f"{src_ip}:{dst_ip}:{port}:{protocol}"
        if self._is_duplicate("network", connection_id, state_lower, timestamp):
            self.stats["network_filtered"] += 1
            return True

        if self._exceeds_frequency("network", connection_id):
            self.stats["network_filtered"] += 1
            return True

        if config.ENABLE_LOOPBACK_FILTER and (src_ip in config.IGNORE_IPS or dst_ip in config.IGNORE_IPS):
            self.stats["network_filtered"] += 1
            return True

        if config.ENABLE_PORT_FILTER and port in config.IGNORE_PORTS:
            self.stats["network_filtered"] += 1
            return True

        if config.ENABLE_STATE_FILTER and state_lower in config.IGNORE_STATES:
            self.stats["network_filtered"] += 1
            return True

        if protocol_lower in config.IGNORE_PROTOCOLS:
            self.stats["network_filtered"] += 1
            return True

        self.stats["network_saved"] += 1
        return False

    def should_ignore_registry(self, registry_key: str, action: str, timestamp: float) -> bool:
        """
        Determine if a registry event should be ignored.
        """
        self.stats["registry_seen"] += 1

        if not registry_key:
            return True

        key_lower = registry_key.lower()

        if config.ENABLE_WHITELIST and whitelist.is_trusted_registry(key_lower):
            self.stats["registry_saved"] += 1
            return False

        # AI Safety Rules - Never ignore critical registry paths
        for critical_path in config.CRITICAL_REGISTRY_PATHS:
            if critical_path in key_lower:
                self.stats["registry_saved"] += 1
                return False

        if not config.ENABLE_REGISTRY_FILTER:
            self.stats["registry_saved"] += 1
            return False

        if self._is_duplicate("registry", key_lower, action, timestamp):
            self.stats["registry_filtered"] += 1
            return True

        if self._exceeds_frequency("registry", key_lower):
            self.stats["registry_filtered"] += 1
            return True

        for ignore_path in config.IGNORE_REGISTRY:
            if ignore_path in key_lower:
                self.stats["registry_filtered"] += 1
                return True

        self.stats["registry_saved"] += 1
        return False

    def should_ignore_event(self, event_type: str, event_data: Dict[str, Any]) -> bool:
        """
        General router for all event types.
        Uses the current time for caching mechanisms.
        """
        timestamp = event_data.get("timestamp", time.time())
        
        if event_type == "file":
            return self.should_ignore_file(
                file_path=event_data.get("path", ""),
                action=event_data.get("action", ""),
                timestamp=timestamp
            )
        elif event_type == "process":
            return self.should_ignore_process(
                process_name=event_data.get("process_name", ""),
                process_path=event_data.get("process_path", ""),
                username=event_data.get("username", ""),
                action=event_data.get("action", ""),
                timestamp=timestamp
            )
        elif event_type == "network":
            return self.should_ignore_network(
                src_ip=event_data.get("src_ip", ""),
                dst_ip=event_data.get("dst_ip", ""),
                port=event_data.get("port", 0),
                protocol=event_data.get("protocol", ""),
                state=event_data.get("state", ""),
                process_name=event_data.get("process_name", ""),
                timestamp=timestamp,
                is_listening_port=event_data.get("is_listening_port", False),
                is_new_outbound=event_data.get("is_new_outbound", False)
            )
        elif event_type == "registry":
            return self.should_ignore_registry(
                registry_key=event_data.get("key", ""),
                action=event_data.get("action", ""),
                timestamp=timestamp
            )
        
        # Unrecognized event types are not ignored to ensure safety
        return False
