"""
Configuration for the telemetry filtering subsystem.
Contains feature toggles and limits. No logic.
"""

ENABLE_FILE_FILTER: bool = True
ENABLE_NETWORK_FILTER: bool = True
ENABLE_PROCESS_FILTER: bool = True
ENABLE_REGISTRY_FILTER: bool = True

ENABLE_DUPLICATE_FILTER: bool = True
# The time window in seconds for duplicate event detection.
DUPLICATE_CACHE_SECONDS: float = 1.0

ENABLE_STATISTICS: bool = True
