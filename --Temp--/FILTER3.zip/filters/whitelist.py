"""
Whitelist definitions for the telemetry filtering subsystem.
Trusted entries here override all other filtering logic.
"""

from typing import Set

TRUSTED_PROCESSES: Set[str] = set()
TRUSTED_PATHS: Set[str] = set()
TRUSTED_IPS: Set[str] = set()
TRUSTED_REGISTRY: Set[str] = set()

def is_trusted_process(process_name: str, process_path: str = "") -> bool:
    """Check if a process is trusted."""
    name_lower = process_name.lower() if process_name else ""
    path_lower = process_path.lower() if process_path else ""
    return name_lower in TRUSTED_PROCESSES or path_lower in TRUSTED_PROCESSES

def is_trusted_path(path: str) -> bool:
    """Check if a path is trusted."""
    if not path:
        return False
    path_lower = path.lower()
    return any(trusted in path_lower for trusted in TRUSTED_PATHS)

def is_trusted_ip(ip_address: str) -> bool:
    """Check if an IP address is trusted."""
    if not ip_address:
        return False
    return ip_address in TRUSTED_IPS

def is_trusted_registry(registry_key: str) -> bool:
    """Check if a registry key is trusted."""
    if not registry_key:
        return False
    key_lower = registry_key.lower()
    return any(trusted in key_lower for trusted in TRUSTED_REGISTRY)
