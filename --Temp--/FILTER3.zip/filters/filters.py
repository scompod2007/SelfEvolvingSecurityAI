"""
Production-quality filtering logic for Self-Evolving Security AI.
Provides fast, thread-safe, modular filtering of OS telemetry events.
"""

import fnmatch
import ipaddress
import threading
import time
from pathlib import Path
from collections import defaultdict
from typing import Set, Dict, Tuple, Any

from . import filter_config as config
from . import whitelist

# --- Static Rule Definitions ---

IGNORE_PATHS: Set[str] = {
    r"appdata\local\temp",
    r"windows\prefetch",
    r"$recycle.bin",
    r"recycler",
}

IGNORE_FILES: Set[str] = {
    "telemetry.db",
    "telemetry.db-journal",
    "telemetry.db-wal",
    "telemetry.db-shm",
}

IGNORE_EXTENSIONS: Set[str] = {
    ".tmp",
    ".temp",
    ".log",
    ".etl",
}

IGNORE_FILE_PATTERNS: Set[str] = {
    "*.tmp",
    "*.etl",
    "*.log",
}

IGNORE_PROCESSES: Set[str] = {
    "system idle process",
}

IGNORE_REGISTRY_PATHS: Set[str] = {
    "volatile environment",
    "muicache",
    r"explorer\recentdocs",
}

IGNORE_TCP_STATES: Set[str] = {
    "time_wait",
}

CRITICAL_EXTENSIONS: Set[str] = {
    ".exe", ".dll", ".sys", ".scr", ".ps1", ".js", ".vbs", ".cmd", ".bat", ".msi"
}

CRITICAL_REGISTRY_PATHS: Set[str] = {
    "run", "runonce", "services", "winlogon", "lsa", "policies", "windows defender"
}

CRITICAL_NETWORK_PROTOCOLS: Set[str] = {
    "http", "https", "dns", "smb", "ssh", "rdp"
}

# --- Thread-Safe State Engine ---

class FilterEngine:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        # fingerprint -> timestamp
        self.duplicate_cache: Dict[Tuple[Any, ...], float] = {}
        # statistics counters
        self.stats: Dict[str, int] = defaultdict(int)

    def increment_stat(self, stat_name: str) -> None:
        if not config.ENABLE_STATISTICS:
            return
        with self.lock:
            self.stats[stat_name] += 1

    def check_duplicate(self, fingerprint: Tuple[Any, ...], current_time: float) -> bool:
        if not config.ENABLE_DUPLICATE_FILTER:
            return False
            
        with self.lock:
            # Cleanup old entries to prevent memory leak
            expired = [k for k, t in self.duplicate_cache.items() if current_time - t > config.DUPLICATE_CACHE_SECONDS]
            for k in expired:
                del self.duplicate_cache[k]
                
            if fingerprint in self.duplicate_cache:
                return True
                
            self.duplicate_cache[fingerprint] = current_time
            return False

_engine = FilterEngine()

# --- Helper Functions ---

def _has_critical_extension(file_path: str) -> bool:
    if not file_path:
        return False
    name = Path(file_path).name.lower()
    for ext in CRITICAL_EXTENSIONS:
        if name.endswith(ext):
            return True
    return False

def _is_loopback(ip_str: str) -> bool:
    if not ip_str:
        return False
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_loopback
    except ValueError:
        return False

def _is_external(ip_str: str) -> bool:
    if not ip_str:
        return False
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_global
    except ValueError:
        return False

# --- Public API ---

def should_ignore_file(file_path: str, action: str, timestamp: float = 0.0) -> bool:
    _engine.increment_stat("Files Seen")
    
    if not file_path:
        _engine.increment_stat("Files Ignored")
        return True
        
    if whitelist.is_trusted_path(file_path):
        _engine.increment_stat("Files Stored")
        return False
        
    if _has_critical_extension(file_path):
        _engine.increment_stat("Files Stored")
        return False
        
    if not config.ENABLE_FILE_FILTER:
        _engine.increment_stat("Files Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("file", file_path.lower(), action)
    if _engine.check_duplicate(fingerprint, timestamp):
        _engine.increment_stat("Files Ignored")
        return True
        
    path_obj = Path(file_path)
    file_name_lower = path_obj.name.lower()
    file_path_lower = str(path_obj).lower()
    
    if file_name_lower in IGNORE_FILES:
        _engine.increment_stat("Files Ignored")
        return True
        
    if path_obj.suffix.lower() in IGNORE_EXTENSIONS:
        _engine.increment_stat("Files Ignored")
        return True
        
    for pattern in IGNORE_FILE_PATTERNS:
        if fnmatch.fnmatch(file_name_lower, pattern):
            _engine.increment_stat("Files Ignored")
            return True
                
    for p in IGNORE_PATHS:
        if p in file_path_lower:
            _engine.increment_stat("Files Ignored")
            return True
                
    _engine.increment_stat("Files Stored")
    return False

def should_ignore_process(process_name: str, process_path: str, action: str, timestamp: float = 0.0) -> bool:
    _engine.increment_stat("Processes Seen")
    
    if whitelist.is_trusted_process(process_name, process_path):
        _engine.increment_stat("Processes Stored")
        return False
        
    if _has_critical_extension(process_path or process_name):
        _engine.increment_stat("Processes Stored")
        return False
        
    if not config.ENABLE_PROCESS_FILTER:
        _engine.increment_stat("Processes Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    identifier = (process_path or process_name or "").lower()
    fingerprint = ("process", identifier, action)
    if _engine.check_duplicate(fingerprint, timestamp):
        _engine.increment_stat("Processes Ignored")
        return True
        
    if (process_name or "").lower() in IGNORE_PROCESSES:
        _engine.increment_stat("Processes Ignored")
        return True
        
    _engine.increment_stat("Processes Stored")
    return False

def should_ignore_network(src_ip: str, dst_ip: str, port: int, protocol: str, state: str, process_name: str, is_listening: bool, action: str = "network", timestamp: float = 0.0) -> bool:
    _engine.increment_stat("Connections Seen")
    
    if whitelist.is_trusted_ip(dst_ip):
        _engine.increment_stat("Connections Stored")
        return False
        
    protocol_lower = (protocol or "").lower()
    
    if is_listening:
        _engine.increment_stat("Connections Stored")
        return False
        
    if not process_name:
        _engine.increment_stat("Connections Stored")
        return False
        
    if _is_external(dst_ip):
        _engine.increment_stat("Connections Stored")
        return False
        
    if protocol_lower in CRITICAL_NETWORK_PROTOCOLS:
        _engine.increment_stat("Connections Stored")
        return False
        
    if not config.ENABLE_NETWORK_FILTER:
        _engine.increment_stat("Connections Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("network", src_ip, dst_ip, port, protocol_lower, state, action)
    if _engine.check_duplicate(fingerprint, timestamp):
        _engine.increment_stat("Connections Ignored")
        return True
        
    if _is_loopback(src_ip) or _is_loopback(dst_ip):
        _engine.increment_stat("Connections Ignored")
        return True
        
    if (state or "").lower() in IGNORE_TCP_STATES:
        _engine.increment_stat("Connections Ignored")
        return True
        
    _engine.increment_stat("Connections Stored")
    return False

def should_ignore_registry(registry_key: str, action: str, timestamp: float = 0.0) -> bool:
    _engine.increment_stat("Registry Seen")
    
    if not registry_key:
        _engine.increment_stat("Registry Ignored")
        return True
        
    if whitelist.is_trusted_registry(registry_key):
        _engine.increment_stat("Registry Stored")
        return False
        
    key_lower = registry_key.lower().replace('/', '\\')
    
    for crit in CRITICAL_REGISTRY_PATHS:
        if crit in key_lower:
            _engine.increment_stat("Registry Stored")
            return False
            
    if not config.ENABLE_REGISTRY_FILTER:
        _engine.increment_stat("Registry Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("registry", key_lower, action)
    if _engine.check_duplicate(fingerprint, timestamp):
        _engine.increment_stat("Registry Ignored")
        return True
        
    for p in IGNORE_REGISTRY_PATHS:
        if p in key_lower:
            _engine.increment_stat("Registry Ignored")
            return True
            
    _engine.increment_stat("Registry Stored")
    return False

def print_statistics() -> None:
    """Print the current statistics. Call this from Telemetry Manager on shutdown."""
    with _engine.lock:
        print("\n=== Filter Statistics ===")
        for key, value in sorted(_engine.stats.items()):
            print(f"{key}: {value}")
        print("=========================\n")
