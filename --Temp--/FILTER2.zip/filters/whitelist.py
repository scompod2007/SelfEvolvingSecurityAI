"""
Whitelist definitions for the telemetry filtering subsystem.
Trusted entries here override all other filtering logic.
"""

def is_trusted_process(process_name: str, process_path: str = "") -> bool:
    """Check if a process is trusted."""
    return False

def is_trusted_file(file_path: str) -> bool:
    """Check if a file path is trusted."""
    return False

def is_trusted_registry(registry_key: str) -> bool:
    """Check if a registry key is trusted."""
    return False

def is_trusted_ip(ip_address: str) -> bool:
    """Check if an IP address is trusted."""
    return False
