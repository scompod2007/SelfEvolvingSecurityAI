"""
Configuration for the telemetry filtering subsystem.
Contains only boolean feature toggles and numeric limits. No logic.
"""

ENABLE_FILE_FILTER: bool = True
ENABLE_PROCESS_FILTER: bool = True
ENABLE_NETWORK_FILTER: bool = True
ENABLE_REGISTRY_FILTER: bool = True

ENABLE_DUPLICATE_FILTER: bool = True
ENABLE_PATTERN_FILTER: bool = True
ENABLE_EXTENSION_FILTER: bool = True
ENABLE_TEMP_FILTER: bool = True
ENABLE_LOOPBACK_FILTER: bool = True
ENABLE_STATISTICS: bool = True

# The time window in seconds for duplicate event detection.
DUPLICATE_WINDOW_SECONDS: int = 1
