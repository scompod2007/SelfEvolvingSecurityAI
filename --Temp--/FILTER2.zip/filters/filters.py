"""
Production-quality filtering logic for Self-Evolving Security AI.
Provides fast, thread-safe, modular filtering of OS telemetry events.
"""

import fnmatch
import ipaddress
import threading
import time
from pathlib import Path
from collections import defaultdict
from typing import Set, Dict, Tuple, Any

from . import filter_config as config
from . import whitelist

# --- Static Rule Definitions ---

IGNORE_PATHS: Set[str] = {
    r"appdata\local\temp",
    r"windows\prefetch",
    r"$recycle.bin",
    r"recycler",
}

IGNORE_FILES: Set[str] = {
    "telemetry.db",
    "telemetry.db-journal",
    "telemetry.db-wal",
    "telemetry.db-shm",
    "thumbs.db",
    "desktop.ini",
}

IGNORE_EXTENSIONS: Set[str] = {
    ".tmp",
    ".temp",
    ".log",
    ".etl",
}

IGNORE_FILE_PATTERNS: Set[str] = {
    "*.tmp",
    "*.etl",
    "*.log",
}

IGNORE_PROCESSES: Set[str] = {
    "system idle process",
}

IGNORE_USERS: Set[str] = {
    "system",
}

IGNORE_REGISTRY_PATHS: Set[str] = {
    "volatile environment",
    "muicache",
    r"explorer\recentdocs",
}

IGNORE_TCP_STATES: Set[str] = {
    "time_wait",
}

CRITICAL_EXTENSIONS: Set[str] = {
    ".exe", ".dll", ".ps1", ".vbs", ".js", ".cmd", ".bat", ".scr"
}

CRITICAL_REGISTRY_PATHS: Set[str] = {
    "run", "runonce", "services", "winlogon", "lsa", "windows defender", "policies"
}

CRITICAL_NETWORK_PROTOCOLS: Set[str] = {
    "http", "https", "dns", "smb", "ssh", "rdp"
}

# --- Thread-Safe State ---

class FilterState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        # fingerprint -> timestamp
        self.duplicate_cache: Dict[Tuple[Any, ...], float] = {}
        
        # Statistics
        self.stats: Dict[str, int] = defaultdict(int)

_state = FilterState()

# --- Helper Functions ---

def _increment_stat(stat_name: str) -> None:
    if not config.ENABLE_STATISTICS:
        return
    with _state.lock:
        _state.stats[stat_name] += 1

def _check_duplicate(fingerprint: Tuple[Any, ...], current_time: float) -> bool:
    if not config.ENABLE_DUPLICATE_FILTER:
        return False
        
    with _state.lock:
        # Cleanup old entries to prevent memory leak
        expired = [k for k, t in _state.duplicate_cache.items() if current_time - t > config.DUPLICATE_WINDOW_SECONDS]
        for k in expired:
            del _state.duplicate_cache[k]
            
        if fingerprint in _state.duplicate_cache:
            # Timestamp matches within window
            _increment_stat("Duplicates Filtered")
            return True
            
        _state.duplicate_cache[fingerprint] = current_time
        return False

def _has_critical_extension(file_path: str) -> bool:
    if not file_path:
        return False
    name = Path(file_path).name.lower()
    for ext in CRITICAL_EXTENSIONS:
        if name.endswith(ext):
            return True
    return False

def _is_loopback(ip_str: str) -> bool:
    if not ip_str:
        return False
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_loopback
    except ValueError:
        return False

def _is_external(ip_str: str) -> bool:
    if not ip_str:
        return False
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_global
    except ValueError:
        return False

# --- Public API ---

def should_ignore_file(file_path: str, action: str, timestamp: float = 0.0) -> bool:
    _increment_stat("Files Seen")
    
    if not file_path:
        _increment_stat("Files Ignored")
        return True
        
    if whitelist.is_trusted_file(file_path):
        _increment_stat("Files Stored")
        return False
        
    if _has_critical_extension(file_path):
        _increment_stat("Files Stored")
        return False
        
    if not config.ENABLE_FILE_FILTER:
        _increment_stat("Files Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("file", file_path.lower(), action)
    if _check_duplicate(fingerprint, timestamp):
        _increment_stat("Files Ignored")
        return True
        
    path_obj = Path(file_path)
    file_name_lower = path_obj.name.lower()
    file_path_lower = str(path_obj).lower()
    
    if file_name_lower in IGNORE_FILES:
        _increment_stat("Files Ignored")
        return True
        
    if config.ENABLE_EXTENSION_FILTER and path_obj.suffix.lower() in IGNORE_EXTENSIONS:
        _increment_stat("Files Ignored")
        return True
        
    if config.ENABLE_PATTERN_FILTER:
        for pattern in IGNORE_FILE_PATTERNS:
            if fnmatch.fnmatch(file_name_lower, pattern):
                _increment_stat("Files Ignored")
                return True
                
    if config.ENABLE_TEMP_FILTER:
        for p in IGNORE_PATHS:
            if p in file_path_lower:
                _increment_stat("Files Ignored")
                return True
                
    _increment_stat("Files Stored")
    return False

def should_ignore_process(process_name: str, process_path: str, username: str, action: str, timestamp: float = 0.0) -> bool:
    _increment_stat("Processes Seen")
    
    if whitelist.is_trusted_process(process_name, process_path):
        _increment_stat("Processes Stored")
        return False
        
    if _has_critical_extension(process_path or process_name):
        _increment_stat("Processes Stored")
        return False
        
    if not config.ENABLE_PROCESS_FILTER:
        _increment_stat("Processes Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    identifier = (process_path or process_name or "").lower()
    fingerprint = ("process", identifier, action)
    if _check_duplicate(fingerprint, timestamp):
        _increment_stat("Processes Ignored")
        return True
        
    if (process_name or "").lower() in IGNORE_PROCESSES:
        _increment_stat("Processes Ignored")
        return True
        
    if (username or "").lower() in IGNORE_USERS:
        _increment_stat("Processes Ignored")
        return True
        
    _increment_stat("Processes Stored")
    return False

def should_ignore_network(src_ip: str, dst_ip: str, port: int, protocol: str, state: str, process_name: str, is_listening: bool, is_new_outbound: bool, action: str = "network", timestamp: float = 0.0) -> bool:
    _increment_stat("Network Seen")
    
    if whitelist.is_trusted_ip(dst_ip):
        _increment_stat("Network Stored")
        return False
        
    protocol_lower = (protocol or "").lower()
    
    if is_listening or is_new_outbound:
        _increment_stat("Network Stored")
        return False
        
    if not process_name:
        _increment_stat("Network Stored")
        return False
        
    if _is_external(dst_ip):
        _increment_stat("Network Stored")
        return False
        
    if protocol_lower in CRITICAL_NETWORK_PROTOCOLS:
        _increment_stat("Network Stored")
        return False
        
    if not config.ENABLE_NETWORK_FILTER:
        _increment_stat("Network Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("network", src_ip, dst_ip, port, protocol_lower, state, action)
    if _check_duplicate(fingerprint, timestamp):
        _increment_stat("Network Ignored")
        return True
        
    if config.ENABLE_LOOPBACK_FILTER and (_is_loopback(src_ip) or _is_loopback(dst_ip)):
        _increment_stat("Network Ignored")
        return True
        
    if (state or "").lower() in IGNORE_TCP_STATES:
        _increment_stat("Network Ignored")
        return True
        
    _increment_stat("Network Stored")
    return False

def should_ignore_registry(registry_key: str, action: str, timestamp: float = 0.0) -> bool:
    _increment_stat("Registry Seen")
    
    if not registry_key:
        _increment_stat("Registry Ignored")
        return True
        
    if whitelist.is_trusted_registry(registry_key):
        _increment_stat("Registry Stored")
        return False
        
    key_lower = registry_key.lower().replace('/', '\\')
    
    for crit in CRITICAL_REGISTRY_PATHS:
        if crit in key_lower:
            _increment_stat("Registry Stored")
            return False
            
    if not config.ENABLE_REGISTRY_FILTER:
        _increment_stat("Registry Stored")
        return False
        
    if timestamp == 0.0:
        timestamp = time.time()
        
    fingerprint = ("registry", key_lower, action)
    if _check_duplicate(fingerprint, timestamp):
        _increment_stat("Registry Ignored")
        return True
        
    for p in IGNORE_REGISTRY_PATHS:
        if p in key_lower:
            _increment_stat("Registry Ignored")
            return True
            
    _increment_stat("Registry Stored")
    return False

def get_statistics() -> Dict[str, int]:
    """Retrieve a copy of the current filter statistics."""
    with _state.lock:
        return dict(_state.stats)

def print_statistics() -> None:
    """Print the current statistics (useful for Telemetry Manager shutdown)."""
    stats = get_statistics()
    print("--- Filter Statistics ---")
    for k, v in stats.items():
        print(f"{k}: {v}")
    print("-------------------------")
