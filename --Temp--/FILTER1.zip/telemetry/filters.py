"""
Production-quality filtering engine for telemetry data.
Designed for the Self-Evolving Security AI to reduce noise without hiding suspicious activity.
"""

import fnmatch
import os
import time
import ipaddress
import logging
import threading
from typing import Dict, Any, Tuple, Optional, Union
from collections import defaultdict
from dataclasses import dataclass

import telemetry.filter_config as config
import telemetry.whitelist as whitelist


class Priority:
    """Event priorities for downstream AI context."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class FilterDecision:
    """Dataclass representing the decision of a filter."""
    ignore: bool
    reason: str
    priority: str
    noise_score: int
    confidence: float

    def __bool__(self) -> bool:
        """Maintains backward compatibility for if-checks."""
        return self.ignore


class TelemetryFilter:
    """
    Modular filtering framework for telemetry events.
    Thread-safe implementation with time-based frequency limiters and duplicate detection.
    """

    def __init__(self) -> None:
        # Cache for duplicate detection: event_fingerprint -> timestamp
        self._duplicate_cache: Dict[Tuple[str, ...], float] = {}
        
        # Frequency limiter: event_fingerprint -> (count, window_start_time)
        self._frequency_cache: Dict[Tuple[str, ...], Tuple[int, float]] = {}
        
        # Statistics for maintaining ignored counters and seen metrics
        self.stats: Dict[str, int] = {
            "files_seen": 0,
            "files_ignored": 0,
            "files_passed": 0,
            "processes_seen": 0,
            "processes_ignored": 0,
            "processes_passed": 0,
            "registry_seen": 0,
            "registry_ignored": 0,
            "registry_passed": 0,
            "network_seen": 0,
            "network_ignored": 0,
            "network_passed": 0,
            "total_duplicates_filtered": 0,
            "total_frequency_filtered": 0,
            "whitelist_bypasses": 0
        }

        # Thread Safety
        self._lock = threading.Lock()
        
        # Logger
        self._logger = logging.getLogger("TelemetryFilter")
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)
            self._logger.setLevel(logging.INFO)

    def _increment_stat(self, stat_name: str) -> None:
        """Increment a statistic safely."""
        if config.ENABLE_THREAD_LOCKS:
            with self._lock:
                if stat_name in self.stats:
                    self.stats[stat_name] += 1
        else:
            if stat_name in self.stats:
                self.stats[stat_name] += 1

    def _clean_duplicate_cache(self, current_time: float) -> None:
        """Remove expired entries from the duplicate cache."""
        expired_keys = [
            k for k, ts in self._duplicate_cache.items()
            if current_time - ts > config.DUPLICATE_CACHE_SECONDS
        ]
        for k in expired_keys:
            del self._duplicate_cache[k]

    def _clean_frequency_cache(self, current_time: float) -> None:
        """Remove expired entries from the frequency cache."""
        expired_keys = [
            k for k, (count, window_start) in self._frequency_cache.items()
            if current_time - window_start > config.EVENT_WINDOW_SECONDS
        ]
        for k in expired_keys:
            del self._frequency_cache[k]

    def _is_duplicate(self, fingerprint: Tuple[str, ...], timestamp: float) -> bool:
        """Check if an event is a duplicate based on its fingerprint within the configured time window."""
        if not config.ENABLE_DUPLICATE_CACHE:
            return False

        if config.ENABLE_THREAD_LOCKS:
            with self._lock:
                self._clean_duplicate_cache(timestamp)
                if fingerprint in self._duplicate_cache:
                    self.stats["total_duplicates_filtered"] += 1
                    return True
                self._duplicate_cache[fingerprint] = timestamp
        else:
            self._clean_duplicate_cache(timestamp)
            if fingerprint in self._duplicate_cache:
                self.stats["total_duplicates_filtered"] += 1
                return True
            self._duplicate_cache[fingerprint] = timestamp

        return False

    def _exceeds_frequency(self, fingerprint: Tuple[str, ...], timestamp: float) -> bool:
        """Check if an event exceeds the maximum allowed frequency within a time window."""
        if not config.ENABLE_FREQUENCY_LIMITER:
            return False

        if config.ENABLE_THREAD_LOCKS:
            with self._lock:
                self._clean_frequency_cache(timestamp)
                if fingerprint in self._frequency_cache:
                    count, window_start = self._frequency_cache[fingerprint]
                    if count >= config.MAX_EVENT_FREQUENCY:
                        self.stats["total_frequency_filtered"] += 1
                        return True
                    self._frequency_cache[fingerprint] = (count + 1, window_start)
                else:
                    self._frequency_cache[fingerprint] = (1, timestamp)
        else:
            self._clean_frequency_cache(timestamp)
            if fingerprint in self._frequency_cache:
                count, window_start = self._frequency_cache[fingerprint]
                if count >= config.MAX_EVENT_FREQUENCY:
                    self.stats["total_frequency_filtered"] += 1
                    return True
                self._frequency_cache[fingerprint] = (count + 1, window_start)
            else:
                self._frequency_cache[fingerprint] = (1, timestamp)

        return False

    def _log_filtered(self, event_type: str, decision: FilterDecision) -> None:
        """Log an event that has been filtered if logging is enabled."""
        if config.LOG_FILTERED_EVENTS:
            self._logger.info(f"Filtered {event_type} | Reason: {decision.reason} | Score: {decision.noise_score} | Priority: {decision.priority}")

    def _has_critical_extension(self, file_name: str) -> bool:
        """Check if a file has a critical extension, including double extensions."""
        parts = file_name.lower().split('.')
        # Check all parts for critical extensions (e.g., payload.exe.tmp)
        for part in parts[1:]:
            if f".{part}" in config.CRITICAL_EXTENSIONS:
                return True
        return False

    def should_ignore_file(self, file_path: str, action: str, timestamp: float, pid: str = "", username: str = "") -> FilterDecision:
        """
        Determine if a file event should be ignored.
        """
        self._increment_stat("files_seen")
        
        if not file_path:
            decision = FilterDecision(ignore=True, reason="Empty file path", priority=Priority.LOW, noise_score=100, confidence=1.0)
            self._increment_stat("files_ignored")
            self._log_filtered("file", decision)
            return decision

        path_lower = file_path.lower()
        file_name = os.path.basename(path_lower)

        # AI Safety Rules - Never ignore critical extensions
        if self._has_critical_extension(file_name):
            decision = FilterDecision(ignore=False, reason="Critical extension", priority=Priority.CRITICAL, noise_score=5, confidence=1.0)
            self._increment_stat("files_passed")
            return decision

        if config.ENABLE_WHITELIST and whitelist.is_trusted_file(file_name):
            self._increment_stat("whitelist_bypasses")
            decision = FilterDecision(ignore=False, reason="Trusted file", priority=Priority.LOW, noise_score=10, confidence=0.9)
            self._increment_stat("files_passed")
            return decision

        if config.ENABLE_WHITELIST and whitelist.is_trusted_path(file_path):
            self._increment_stat("whitelist_bypasses")
            decision = FilterDecision(ignore=False, reason="Trusted path", priority=Priority.LOW, noise_score=10, confidence=0.9)
            self._increment_stat("files_passed")
            return decision

        if not config.ENABLE_FILE_FILTER:
            decision = FilterDecision(ignore=False, reason="File filter disabled", priority=Priority.MEDIUM, noise_score=50, confidence=1.0)
            self._increment_stat("files_passed")
            return decision

        # Fingerprint: type, path, action, pid, user
        fingerprint = ("file", path_lower, action, pid, username)
        
        if self._is_duplicate(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Duplicate event", priority=Priority.LOW, noise_score=95, confidence=1.0)
            self._increment_stat("files_ignored")
            self._log_filtered("file", decision)
            return decision

        if self._exceeds_frequency(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Frequency limit exceeded", priority=Priority.LOW, noise_score=90, confidence=1.0)
            self._increment_stat("files_ignored")
            self._log_filtered("file", decision)
            return decision

        # Ignore specific database files
        if file_name in config.IGNORE_FILES:
            decision = FilterDecision(ignore=True, reason="Ignored database file", priority=Priority.LOW, noise_score=100, confidence=1.0)
            self._increment_stat("files_ignored")
            self._log_filtered("file", decision)
            return decision

        _, ext = os.path.splitext(file_name)
        # Ignore by extension
        if config.ENABLE_EXTENSION_FILTER and ext in config.IGNORE_EXTENSIONS:
            decision = FilterDecision(ignore=True, reason="Ignored extension", priority=Priority.LOW, noise_score=95, confidence=0.95)
            self._increment_stat("files_ignored")
            self._log_filtered("file", decision)
            return decision

        # Ignore by pattern
        if config.ENABLE_PATTERN_FILTER:
            for pattern in config.IGNORE_PATTERNS:
                if fnmatch.fnmatch(file_name, pattern):
                    decision = FilterDecision(ignore=True, reason="Ignored pattern", priority=Priority.LOW, noise_score=90, confidence=0.9)
                    self._increment_stat("files_ignored")
                    self._log_filtered("file", decision)
                    return decision

        # Ignore by path
        for ignore_path in config.IGNORE_PATHS:
            if ignore_path in path_lower:
                decision = FilterDecision(ignore=True, reason="Ignored path", priority=Priority.LOW, noise_score=90, confidence=0.9)
                self._increment_stat("files_ignored")
                self._log_filtered("file", decision)
                return decision

        priority = Priority.HIGH if "temp" in path_lower and self._has_critical_extension(file_name) else Priority.MEDIUM
        noise_score = 30 if priority == Priority.HIGH else 40
        decision = FilterDecision(ignore=False, reason="Allowed", priority=priority, noise_score=noise_score, confidence=1.0)
        self._increment_stat("files_passed")
        return decision

    def should_ignore_process(self, process_name: str, process_path: str, username: str, action: str, timestamp: float, pid: str = "") -> FilterDecision:
        """
        Determine if a process event should be ignored.
        """
        self._increment_stat("processes_seen")

        if not process_name and not process_path:
            decision = FilterDecision(ignore=True, reason="Empty process details", priority=Priority.LOW, noise_score=100, confidence=1.0)
            self._increment_stat("processes_ignored")
            self._log_filtered("process", decision)
            return decision

        process_name_lower = process_name.lower() if process_name else ""
        process_path_lower = process_path.lower() if process_path else ""
        username_lower = username.lower() if username else ""

        if self._has_critical_extension(process_path_lower if process_path_lower else process_name_lower):
            decision = FilterDecision(ignore=False, reason="Critical extension", priority=Priority.CRITICAL, noise_score=5, confidence=1.0)
            self._increment_stat("processes_passed")
            return decision

        if config.ENABLE_WHITELIST and whitelist.is_trusted_process(process_name_lower):
            self._increment_stat("whitelist_bypasses")
            decision = FilterDecision(ignore=False, reason="Trusted process", priority=Priority.LOW, noise_score=10, confidence=0.9)
            self._increment_stat("processes_passed")
            return decision

        if not config.ENABLE_PROCESS_FILTER:
            decision = FilterDecision(ignore=False, reason="Process filter disabled", priority=Priority.MEDIUM, noise_score=50, confidence=1.0)
            self._increment_stat("processes_passed")
            return decision

        identifier = process_path_lower if process_path_lower else process_name_lower
        fingerprint = ("process", identifier, action, username_lower, pid)
        
        if self._is_duplicate(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Duplicate event", priority=Priority.LOW, noise_score=95, confidence=1.0)
            self._increment_stat("processes_ignored")
            self._log_filtered("process", decision)
            return decision

        if self._exceeds_frequency(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Frequency limit exceeded", priority=Priority.LOW, noise_score=90, confidence=1.0)
            self._increment_stat("processes_ignored")
            self._log_filtered("process", decision)
            return decision

        if process_name_lower in config.IGNORE_PROCESSES:
            decision = FilterDecision(ignore=True, reason="Ignored process", priority=Priority.LOW, noise_score=95, confidence=0.95)
            self._increment_stat("processes_ignored")
            self._log_filtered("process", decision)
            return decision

        if username_lower in config.IGNORE_USERS:
            decision = FilterDecision(ignore=True, reason="Ignored user", priority=Priority.LOW, noise_score=95, confidence=0.95)
            self._increment_stat("processes_ignored")
            self._log_filtered("process", decision)
            return decision

        # Unknown process logic
        is_unknown = not process_path_lower
        is_powershell = "powershell" in process_name_lower or "pwsh" in process_name_lower
        
        if is_powershell and is_unknown:
            priority = Priority.CRITICAL
            noise_score = 2
        elif is_unknown:
            priority = Priority.HIGH
            noise_score = 3
        else:
            priority = Priority.MEDIUM
            noise_score = 45

        decision = FilterDecision(ignore=False, reason="Allowed", priority=priority, noise_score=noise_score, confidence=0.8)
        self._increment_stat("processes_passed")
        return decision

    def _is_private_ip(self, ip_str: str) -> bool:
        """Check if an IP is private, loopback, etc using ipaddress module."""
        try:
            ip = ipaddress.ip_address(ip_str)
            return ip.is_private or ip.is_loopback or ip.is_multicast or ip.is_reserved or ip.is_unspecified or ip.is_link_local
        except ValueError:
            return False

    def should_ignore_network(
        self,
        src_ip: str,
        dst_ip: str,
        port: int,
        protocol: str,
        state: str,
        process_name: str,
        timestamp: float,
        is_listening_port: bool = False,
        is_new_outbound: bool = False,
        pid: str = "",
        username: str = ""
    ) -> FilterDecision:
        """
        Determine if a network event should be ignored.
        """
        self._increment_stat("network_seen")
        
        protocol_lower = protocol.lower() if protocol else ""
        state_lower = state.lower() if state else ""

        if config.ENABLE_WHITELIST and whitelist.is_trusted_ip(dst_ip):
            self._increment_stat("whitelist_bypasses")
            decision = FilterDecision(ignore=False, reason="Trusted IP", priority=Priority.LOW, noise_score=10, confidence=0.9)
            self._increment_stat("network_passed")
            return decision

        # AI Safety Rules - Never ignore
        if is_listening_port:
            decision = FilterDecision(ignore=False, reason="Listening port", priority=Priority.HIGH, noise_score=20, confidence=0.9)
            self._increment_stat("network_passed")
            return decision
            
        if is_new_outbound:
            decision = FilterDecision(ignore=False, reason="New outbound connection", priority=Priority.HIGH, noise_score=25, confidence=0.9)
            self._increment_stat("network_passed")
            return decision

        if protocol_lower in config.CRITICAL_NETWORK_PROTOCOLS:
            decision = FilterDecision(ignore=False, reason="Critical protocol", priority=Priority.HIGH, noise_score=20, confidence=0.9)
            self._increment_stat("network_passed")
            return decision
            
        if not process_name:
            decision = FilterDecision(ignore=False, reason="Unknown process", priority=Priority.CRITICAL, noise_score=10, confidence=0.95)
            self._increment_stat("network_passed")
            return decision

        is_external = dst_ip and not self._is_private_ip(dst_ip)
        if is_external and dst_ip not in config.IGNORE_IPS:
            decision = FilterDecision(ignore=False, reason="External IP", priority=Priority.HIGH, noise_score=30, confidence=0.8)
            self._increment_stat("network_passed")
            return decision

        if not config.ENABLE_NETWORK_FILTER:
            decision = FilterDecision(ignore=False, reason="Network filter disabled", priority=Priority.MEDIUM, noise_score=50, confidence=1.0)
            self._increment_stat("network_passed")
            return decision

        fingerprint = ("network", src_ip, dst_ip, str(port), protocol_lower, state_lower, process_name, pid, username)
        if self._is_duplicate(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Duplicate event", priority=Priority.LOW, noise_score=95, confidence=1.0)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        if self._exceeds_frequency(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Frequency limit exceeded", priority=Priority.LOW, noise_score=90, confidence=1.0)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        if config.ENABLE_LOOPBACK_FILTER and (self._is_private_ip(src_ip) and self._is_private_ip(dst_ip)):
            decision = FilterDecision(ignore=True, reason="Local/Loopback traffic", priority=Priority.LOW, noise_score=80, confidence=0.8)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        if config.ENABLE_PORT_FILTER and port in config.IGNORE_PORTS:
            decision = FilterDecision(ignore=True, reason="Ignored port", priority=Priority.LOW, noise_score=90, confidence=0.9)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        if config.ENABLE_STATE_FILTER and state_lower in config.IGNORE_STATES:
            decision = FilterDecision(ignore=True, reason="Ignored state", priority=Priority.LOW, noise_score=95, confidence=0.95)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        if protocol_lower in config.IGNORE_PROTOCOLS:
            decision = FilterDecision(ignore=True, reason="Ignored protocol", priority=Priority.LOW, noise_score=90, confidence=0.9)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        # Exclude repetitive ESTABLISHED states if configured, unless they are new outbound
        if config.ENABLE_REPETITIVE_ESTABLISHED_FILTER and state_lower == "established":
            decision = FilterDecision(ignore=True, reason="Repetitive ESTABLISHED", priority=Priority.LOW, noise_score=85, confidence=0.9)
            self._increment_stat("network_ignored")
            self._log_filtered("network", decision)
            return decision

        decision = FilterDecision(ignore=False, reason="Allowed", priority=Priority.MEDIUM, noise_score=45, confidence=0.8)
        self._increment_stat("network_passed")
        return decision

    def should_ignore_registry(self, registry_key: str, action: str, timestamp: float, pid: str = "", username: str = "") -> FilterDecision:
        """
        Determine if a registry event should be ignored.
        Uses exact path matching and normalized paths.
        """
        self._increment_stat("registry_seen")

        if not registry_key:
            decision = FilterDecision(ignore=True, reason="Empty registry key", priority=Priority.LOW, noise_score=100, confidence=1.0)
            self._increment_stat("registry_ignored")
            self._log_filtered("registry", decision)
            return decision

        # Normalize paths
        key_lower = os.path.normpath(registry_key).lower().replace('/', '\\')

        # AI Safety Rules - Never ignore critical registry paths
        for critical_path in config.CRITICAL_REGISTRY_PATHS:
            if critical_path in key_lower:
                decision = FilterDecision(ignore=False, reason="Critical registry path", priority=Priority.CRITICAL, noise_score=5, confidence=0.95)
                self._increment_stat("registry_passed")
                return decision

        if config.ENABLE_WHITELIST and whitelist.is_trusted_registry(key_lower):
            self._increment_stat("whitelist_bypasses")
            decision = FilterDecision(ignore=False, reason="Trusted registry", priority=Priority.LOW, noise_score=10, confidence=0.9)
            self._increment_stat("registry_passed")
            return decision

        if not config.ENABLE_REGISTRY_FILTER:
            decision = FilterDecision(ignore=False, reason="Registry filter disabled", priority=Priority.MEDIUM, noise_score=50, confidence=1.0)
            self._increment_stat("registry_passed")
            return decision

        fingerprint = ("registry", key_lower, action, pid, username)
        if self._is_duplicate(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Duplicate event", priority=Priority.LOW, noise_score=95, confidence=1.0)
            self._increment_stat("registry_ignored")
            self._log_filtered("registry", decision)
            return decision

        if self._exceeds_frequency(fingerprint, timestamp):
            decision = FilterDecision(ignore=True, reason="Frequency limit exceeded", priority=Priority.LOW, noise_score=90, confidence=1.0)
            self._increment_stat("registry_ignored")
            self._log_filtered("registry", decision)
            return decision

        # Exact matching for ignore paths to prevent substring matching errors
        for ignore_path in config.IGNORE_REGISTRY:
            norm_ignore = os.path.normpath(ignore_path).lower().replace('/', '\\')
            if key_lower == norm_ignore or key_lower.startswith(f"{norm_ignore}\\"):
                decision = FilterDecision(ignore=True, reason="Ignored registry path", priority=Priority.LOW, noise_score=90, confidence=0.9)
                self._increment_stat("registry_ignored")
                self._log_filtered("registry", decision)
                return decision

        decision = FilterDecision(ignore=False, reason="Allowed", priority=Priority.MEDIUM, noise_score=45, confidence=0.8)
        self._increment_stat("registry_passed")
        return decision

    def should_ignore_event(self, event_type: str, event_data: Dict[str, Any]) -> FilterDecision:
        """
        General router for all event types.
        """
        timestamp = event_data.get("timestamp", time.time())
        pid = str(event_data.get("pid", ""))
        username = event_data.get("username", "")
        
        if event_type == "file":
            return self.should_ignore_file(
                file_path=event_data.get("path", ""),
                action=event_data.get("action", ""),
                timestamp=timestamp,
                pid=pid,
                username=username
            )
        elif event_type == "process":
            return self.should_ignore_process(
                process_name=event_data.get("process_name", ""),
                process_path=event_data.get("process_path", ""),
                username=username,
                action=event_data.get("action", ""),
                timestamp=timestamp,
                pid=pid
            )
        elif event_type == "network":
            return self.should_ignore_network(
                src_ip=event_data.get("src_ip", ""),
                dst_ip=event_data.get("dst_ip", ""),
                port=event_data.get("port", 0),
                protocol=event_data.get("protocol", ""),
                state=event_data.get("state", ""),
                process_name=event_data.get("process_name", ""),
                timestamp=timestamp,
                is_listening_port=event_data.get("is_listening_port", False),
                is_new_outbound=event_data.get("is_new_outbound", False),
                pid=pid,
                username=username
            )
        elif event_type == "registry":
            return self.should_ignore_registry(
                registry_key=event_data.get("key", ""),
                action=event_data.get("action", ""),
                timestamp=timestamp,
                pid=pid,
                username=username
            )
        
        decision = FilterDecision(ignore=False, reason="Unrecognized event type", priority=Priority.HIGH, noise_score=20, confidence=0.9)
        return decision

    def print_statistics(self) -> None:
        """Print statistics during shutdown."""
        self._logger.info("=== Filter Statistics ===")
        # Print with locks to ensure correct values
        if config.ENABLE_THREAD_LOCKS:
            with self._lock:
                stats_copy = dict(self.stats)
        else:
            stats_copy = dict(self.stats)

        for key, value in stats_copy.items():
            self._logger.info(f"{key}: {value}")
        self._logger.info("=========================")
